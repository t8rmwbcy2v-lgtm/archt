package com.arch.tv

import android.content.Context
import android.graphics.Bitmap
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ImageView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.Executors

/**
 * Cycles photos behind the home screen with a slow crossfade. Sources (switch each on or off in settings):
 *  - Scenic: Bing's daily pictures from several regions
 *  - Space: NASA's astronomy picture archive
 *  - Mine: photos you've added from your phone or laptop
 * Online photos are cached on the device, so they load instantly and still work if the internet drops.
 */
class Slideshow(
    ctx: Context,
    private val old: ImageView,
    private val new: ImageView,
    private val prefs: Prefs
) {
    private val app = ctx.applicationContext
    private val handler = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val dir = File(app.cacheDir, "bg").apply { mkdirs() }

    private var items: List<String> = emptyList()
    private var idx = 0
    private var gen = 0
    private var fails = 0
    private var running = false

    fun start() {
        if (running) return
        running = true
        val g = ++gen
        io.execute {
            val list = loadItems()
            handler.post {
                if (g == gen) {
                    items = list
                    step(g)
                }
            }
        }
    }

    fun stop(clear: Boolean = false) {
        running = false
        gen++
        handler.removeCallbacksAndMessages(null)
        new.animate().cancel()
        if (clear) {
            old.setImageDrawable(null)
            new.setImageDrawable(null)
            new.alpha = 0f
            GlassBackdrop.setBase(null)
        }
    }

    private fun step(g: Int) {
        if (g != gen) return
        if (items.isEmpty()) {
            // nothing yet (probably offline, or every source is switched off): look again in a bit
            handler.postDelayed({
                if (g == gen) {
                    running = false
                    start()
                }
            }, 30_000)
            return
        }
        val item = items[idx++ % items.size]
        io.execute {
            val bmp = loadBitmap(item)
            handler.post {
                if (g != gen) return@post
                if (bmp != null) {
                    fails = 0
                    show(bmp)
                    handler.postDelayed({ step(g) }, prefs.intervalMs)
                } else {
                    fails++
                    val wait = if (fails >= items.size) 60_000L else 3_000L
                    handler.postDelayed({ step(g) }, wait)
                }
            }
        }
    }

    private fun show(bmp: Bitmap) {
        GlassBackdrop.setBase(bmp)
        new.setImageBitmap(bmp)
        new.alpha = 0f
        new.visibility = View.VISIBLE
        new.animate().alpha(1f).setDuration(1500).withEndAction {
            old.setImageBitmap(bmp)
            new.alpha = 0f
        }.start()
    }

    // ---------- building the playlist ----------

    private fun loadItems(): List<String> {
        val groups = ArrayList<List<String>>()
        if (prefs.srcBing) bingList().takeIf { it.isNotEmpty() }?.let { groups += it.shuffled() }
        if (prefs.srcSpace) spaceList().takeIf { it.isNotEmpty() }?.let { groups += it.shuffled() }
        if (prefs.srcMine) {
            PhotoStore.list(app).map { it.path }.takeIf { it.isNotEmpty() }?.let { groups += it.shuffled() }
        }
        if (groups.isEmpty()) return emptyList()
        // each switched-on source gets equal airtime, however many photos it has
        val n = groups.maxOf { it.size }
        val out = ArrayList<String>()
        for (i in 0 until n) for (g in groups) out += g[i % g.size]
        return out
    }

    private fun bingList(): List<String> {
        val now = System.currentTimeMillis()
        val cached = prefs.bgUrls.split("\n").filter { it.startsWith("http") }
        if (cached.isNotEmpty() && now - prefs.bgUrlsTime < 12 * 3_600_000L) return cached

        // the first region right now, so photos show quickly...
        val first = fetchBing(MARKETS[0])
        val merged = (first + cached).distinct().take(200)
        if (merged.isNotEmpty()) {
            prefs.bgUrls = merged.joinToString("\n")
            prefs.bgUrlsTime = now
        }
        // ...and the other regions in the background, ready for next time
        Thread {
            val more = ArrayList<String>()
            for (m in MARKETS.drop(1)) more += fetchBing(m)
            if (more.isNotEmpty()) {
                val all = (more + prefs.bgUrls.split("\n").filter { it.startsWith("http") }).distinct().take(200)
                prefs.bgUrls = all.joinToString("\n")
            }
        }.start()
        return merged.ifEmpty { cached }
    }

    private fun fetchBing(market: String): List<String> {
        val out = ArrayList<String>()
        val body = Net.get("https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=8&mkt=$market") ?: return out
        try {
            val arr = JSONObject(body).getJSONArray("images")
            for (i in 0 until arr.length()) {
                val u = arr.getJSONObject(i).optString("url", "")
                if (u.isNotEmpty()) out += if (u.startsWith("http")) u else "https://www.bing.com$u"
            }
        } catch (_: Exception) {
        }
        return out
    }

    private fun spaceList(): List<String> {
        val now = System.currentTimeMillis()
        val cached = prefs.spaceUrls.split("\n").filter { it.startsWith("http") }
        if (cached.isNotEmpty() && now - prefs.spaceUrlsTime < 24 * 3_600_000L) return cached
        val body = Net.get("https://api.nasa.gov/planetary/apod?api_key=DEMO_KEY&count=30", 20_000)
            ?: return cached
        val out = ArrayList<String>()
        try {
            val arr = JSONArray(body)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                if (o.optString("media_type") != "image") continue
                val u = o.optString("url", "").replace("http://", "https://")
                if (u.startsWith("https")) out += u
            }
        } catch (_: Exception) {
        }
        if (out.isEmpty()) return cached
        val merged = (out + cached).distinct().take(120)
        prefs.spaceUrls = merged.joinToString("\n")
        prefs.spaceUrlsTime = now
        return merged
    }

    // ---------- loading + caching ----------

    private fun loadBitmap(item: String): Bitmap? {
        return try {
            val path: String
            if (item.startsWith("/")) {
                path = item // one of your own photos
            } else {
                val f = File(dir, Integer.toHexString(item.hashCode()) + ".jpg")
                if (!f.exists() || f.length() < 10_000) {
                    if (!Net.download(item, f)) {
                        f.delete()
                        return null
                    }
                    trimCache()
                }
                path = f.path
            }
            val bmp = ImageLoader.decodeFile(path, 1920)
            if (bmp != null) prefs.lastBg = path
            bmp
        } catch (t: Throwable) {
            null
        }
    }

    private fun trimCache() {
        val files = dir.listFiles { f -> f.name.endsWith(".jpg") } ?: return
        files.sortedByDescending { it.lastModified() }.drop(60).forEach { it.delete() }
    }

    companion object {
        private val MARKETS = listOf(
            "en-US", "en-AU", "en-GB", "en-CA", "de-DE", "fr-FR", "ja-JP", "en-IN", "es-ES", "it-IT"
        )
    }
}
