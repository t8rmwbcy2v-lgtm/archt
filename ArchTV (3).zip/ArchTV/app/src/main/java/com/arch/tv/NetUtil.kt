package com.arch.tv

import java.net.Inet4Address
import java.net.NetworkInterface

object NetUtil {
    /** The TV's address on your home network, like 192.168.1.23 (null if it isn't connected). */
    fun localIp(): String? {
        return try {
            val found = ArrayList<Pair<String, String>>()
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (addr in ni.inetAddresses) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress && addr.isSiteLocalAddress) {
                        val host = addr.hostAddress ?: continue
                        found += ni.name to host
                    }
                }
            }
            (found.firstOrNull { it.first.startsWith("wlan") || it.first.startsWith("eth") } ?: found.firstOrNull())
                ?.second
        } catch (e: Exception) {
            null
        }
    }
}
