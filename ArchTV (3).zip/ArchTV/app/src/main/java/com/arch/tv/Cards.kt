package com.arch.tv

import android.graphics.drawable.Drawable
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CardAdapter(
    private val onClick: (Card) -> Unit,
    private val onLongClick: (Card) -> Unit,
    private val art: (String) -> Drawable?
) : RecyclerView.Adapter<CardAdapter.VH>() {

    var items: List<Card> = emptyList()
        private set

    /** Returns true if the cards changed (so the row was rebuilt). */
    fun submit(list: List<Card>): Boolean {
        if (list == items) return false
        items = list
        notifyDataSetChanged()
        return true
    }

    class VH(view: View) : RecyclerView.ViewHolder(view) {
        val poster: ImageView = view.findViewById(R.id.poster)
        val progress: ProgressBar = view.findViewById(R.id.progress)
        val title: TextView = view.findViewById(R.id.title)
        val sub: TextView = view.findViewById(R.id.sub)
        val source: TextView = view.findViewById(R.id.source)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_card, parent, false)
        v.setOnFocusChangeListener { view, hasFocus ->
            val s = if (hasFocus) 1.08f else 1f
            view.animate().scaleX(s).scaleY(s).setDuration(130).start()
        }
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val c = items[position]
        val d = holder.itemView.resources.displayMetrics.density

        holder.title.text = c.title
        holder.sub.text = c.subtitle
        holder.sub.visibility = if (c.subtitle.isEmpty()) View.GONE else View.VISIBLE
        holder.source.text = c.source
        holder.source.setTextColor(Look.accent)

        if (c.progress >= 0f) {
            holder.progress.visibility = View.VISIBLE
            holder.progress.progress = (c.progress * 1000).toInt()
        } else {
            holder.progress.visibility = View.GONE
        }

        // Show the app's banner/icon until the real picture arrives
        val pad = (28 * d).toInt()
        holder.poster.setPadding(pad, pad, pad, pad)
        holder.poster.scaleType = ImageView.ScaleType.CENTER_INSIDE
        holder.poster.setImageDrawable(art(c.pkg))

        val uri = c.imageUri
        holder.poster.tag = uri
        if (uri != null) {
            ImageLoader.load(holder.itemView.context, uri, 640) { bmp ->
                if (bmp != null && holder.poster.tag == uri) {
                    holder.poster.setPadding(0, 0, 0, 0)
                    holder.poster.scaleType = ImageView.ScaleType.CENTER_CROP
                    holder.poster.setImageBitmap(bmp)
                }
            }
        }

        holder.itemView.setOnClickListener { onClick(c) }
        holder.itemView.setOnLongClickListener {
            onLongClick(c)
            true
        }
    }

    override fun getItemCount() = items.size
}
