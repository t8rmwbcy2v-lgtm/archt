package com.arch.tv

/** The accent colour picked in settings, shared by every screen. */
object Look {
    @Volatile
    var accent: Int = 0xFF7FB0FF.toInt()
}
