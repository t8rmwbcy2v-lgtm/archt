package com.arch.tv

import android.webkit.MimeTypeMap
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.concurrent.Executors

/**
 * A tiny web server that lives inside the app. Open its address on a phone or laptop
 * (same Wi-Fi), enter the PIN, and you can upload, download, and manage files.
 * Files are streamed straight to disk, so big videos don't need extra temporary space.
 */
class UploadServer(
    private val root: File,
    private val pin: String,
    private val allowedExt: Set<String>?,
    private val onChanged: () -> Unit
) {
    private val rootCanon: File = root.canonicalFile
    private val pool = Executors.newCachedThreadPool()
    private var server: ServerSocket? = null

    @Volatile
    private var running = false
    private var failCount = 0
    private var lockedUntil = 0L

    /** Starts listening. Returns the port, or -1 if nothing could be started. */
    fun start(): Int {
        for (port in 8080..8090) {
            try {
                val s = ServerSocket()
                s.reuseAddress = true
                s.bind(InetSocketAddress(port))
                server = s
                running = true
                pool.execute { acceptLoop(s) }
                return port
            } catch (e: Exception) {
                // port busy, try the next one
            }
        }
        return -1
    }

    fun stop() {
        running = false
        try {
            server?.close()
        } catch (_: Exception) {
        }
        pool.shutdownNow()
    }

    private fun acceptLoop(s: ServerSocket) {
        while (running) {
            val c = try {
                s.accept()
            } catch (e: Exception) {
                break
            }
            try {
                pool.execute { handle(c) }
            } catch (e: Exception) {
                try {
                    c.close()
                } catch (_: Exception) {
                }
                break
            }
        }
    }

    // ---------------- request handling ----------------

    private fun handle(sock: Socket) {
        try {
            sock.soTimeout = 60_000
            val input = BufferedInputStream(sock.getInputStream(), 65536)
            val out = sock.getOutputStream()
            val requestLine = readLine(input) ?: return
            val parts = requestLine.split(" ")
            if (parts.size < 2) return
            val method = parts[0]
            val target = parts[1]

            val headers = HashMap<String, String>()
            while (true) {
                val line = readLine(input) ?: break
                if (line.isEmpty()) break
                val i = line.indexOf(':')
                if (i > 0) headers[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
            }

            val qIdx = target.indexOf('?')
            val path = if (qIdx >= 0) target.substring(0, qIdx) else target
            val query = parseQuery(if (qIdx >= 0) target.substring(qIdx + 1) else "")
            route(method, path, query, headers, input, out)
        } catch (e: Exception) {
            // client went away or sent junk; nothing to do
        } finally {
            try {
                sock.close()
            } catch (_: Exception) {
            }
        }
    }

    private fun route(
        method: String,
        path: String,
        q: Map<String, String>,
        h: Map<String, String>,
        input: InputStream,
        out: OutputStream
    ) {
        if (method == "GET" && (path == "/" || path == "/index.html")) {
            send(out, 200, "text/html; charset=utf-8", Page.HTML.toByteArray(Charsets.UTF_8))
            return
        }
        if (!path.startsWith("/api/")) {
            sendError(out, 404, "Not found")
            return
        }
        when (checkPin(q["pin"])) {
            429 -> {
                sendError(out, 429, "Too many wrong PINs. Wait 30 seconds.")
                return
            }
            403 -> {
                sendError(out, 403, "Wrong PIN")
                return
            }
        }
        when (path) {
            "/api/list" -> list(out, q)
            "/api/upload" -> if (method == "PUT") upload(out, q, h, input) else sendError(out, 405, "Use PUT")
            "/api/download" -> download(out, q)
            "/api/mkdir" -> mkdir(out, q)
            "/api/delete" -> delete(out, q)
            else -> sendError(out, 404, "Not found")
        }
    }

    /** 0 = ok, 403 = wrong, 429 = locked out for a bit after too many wrong tries. */
    @Synchronized
    private fun checkPin(given: String?): Int {
        val now = System.currentTimeMillis()
        if (now < lockedUntil) return 429
        if (given != null && MessageDigest.isEqual(given.toByteArray(), pin.toByteArray())) {
            failCount = 0
            return 0
        }
        failCount++
        if (failCount >= 5) {
            failCount = 0
            lockedUntil = now + 30_000
        }
        return 403
    }

    // ---------------- API ----------------

    private fun list(out: OutputStream, q: Map<String, String>) {
        val dir = resolve(q["path"])
        if (dir == null || !dir.isDirectory) {
            sendError(out, 404, "Folder not found")
            return
        }
        val files = dir.listFiles()?.filter { !it.name.endsWith(".part") && !it.name.startsWith(".") }
            ?: emptyList()
        val arr = JSONArray()
        files.sortedWith(compareBy<File>({ !it.isDirectory }, { it.name.lowercase() })).forEach { f ->
            arr.put(
                JSONObject()
                    .put("name", f.name)
                    .put("dir", f.isDirectory)
                    .put("size", if (f.isDirectory) 0L else f.length())
            )
        }
        json(out, 200, JSONObject().put("items", arr).put("free", rootCanon.usableSpace))
    }

    private fun upload(out: OutputStream, q: Map<String, String>, h: Map<String, String>, input: InputStream) {
        val len = h["content-length"]?.toLongOrNull()
        if (len == null || len < 0) {
            sendError(out, 411, "Missing file size")
            return
        }
        val dir = resolve(q["path"])
        if (dir == null || !dir.isDirectory) {
            sendError(out, 404, "Folder not found")
            return
        }
        val name = FileUtil.cleanName(q["name"] ?: "")
        if (name.isEmpty()) {
            sendError(out, 400, "Bad file name")
            return
        }
        if (allowedExt != null && File(name).extension.lowercase() !in allowedExt) {
            sendError(out, 400, "Only photos can be added here")
            return
        }
        if (len > dir.usableSpace - 50L * 1024 * 1024) {
            sendError(out, 507, "Not enough space left on the TV")
            return
        }

        val target = FileUtil.uniqueFile(dir, name)
        val tmp = File(dir, target.name + ".part")
        var ok = false
        try {
            FileOutputStream(tmp).use { fos ->
                val buf = ByteArray(65536)
                var left = len
                while (left > 0) {
                    val n = input.read(buf, 0, minOf(buf.size.toLong(), left).toInt())
                    if (n < 0) break
                    fos.write(buf, 0, n)
                    left -= n
                }
                ok = left == 0L
            }
        } catch (e: Exception) {
            ok = false
        }
        if (ok && tmp.renameTo(target)) {
            onChanged()
            json(out, 200, JSONObject().put("ok", true).put("name", target.name))
        } else {
            tmp.delete()
            sendError(out, 500, "Upload failed")
        }
    }

    private fun download(out: OutputStream, q: Map<String, String>) {
        val f = resolve(q["path"])
        if (f == null || !f.isFile) {
            sendError(out, 404, "File not found")
            return
        }
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(FileUtil.ext(f)) ?: "application/octet-stream"
        val encoded = URLEncoder.encode(f.name, "UTF-8").replace("+", "%20")
        val head = "HTTP/1.1 200 OK\r\n" +
            "Content-Type: $mime\r\n" +
            "Content-Length: ${f.length()}\r\n" +
            "Content-Disposition: attachment; filename*=UTF-8''$encoded\r\n" +
            "Connection: close\r\n\r\n"
        out.write(head.toByteArray(Charsets.ISO_8859_1))
        FileInputStream(f).use { it.copyTo(out, 65536) }
        out.flush()
    }

    private fun mkdir(out: OutputStream, q: Map<String, String>) {
        val dir = resolve(q["path"])
        if (dir == null || !dir.isDirectory) {
            sendError(out, 404, "Folder not found")
            return
        }
        val name = FileUtil.cleanName(q["name"] ?: "")
        if (name.isEmpty()) {
            sendError(out, 400, "Bad folder name")
            return
        }
        val f = File(dir, name)
        if (f.exists()) {
            sendError(out, 400, "That name is already taken")
            return
        }
        if (!f.mkdir()) {
            sendError(out, 500, "Couldn't create the folder")
            return
        }
        onChanged()
        json(out, 200, JSONObject().put("ok", true))
    }

    private fun delete(out: OutputStream, q: Map<String, String>) {
        val f = resolve(q["path"])
        if (f == null || f.path == rootCanon.path || !f.exists()) {
            sendError(out, 400, "Nothing to delete")
            return
        }
        f.deleteRecursively()
        onChanged()
        json(out, 200, JSONObject().put("ok", true))
    }

    // ---------------- helpers ----------------

    /** Turns "Videos/Holiday" into a real folder, refusing anything that escapes the root. */
    private fun resolve(rel: String?): File? {
        return try {
            val f = File(rootCanon, (rel ?: "").trim('/')).canonicalFile
            if (f.path == rootCanon.path || f.path.startsWith(rootCanon.path + File.separator)) f else null
        } catch (e: Exception) {
            null
        }
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = input.read()
            if (b == -1) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) break
            if (b != '\r'.code) sb.append(b.toChar())
            if (sb.length > 8192) return null
        }
        return sb.toString()
    }

    private fun parseQuery(raw: String): Map<String, String> {
        val m = HashMap<String, String>()
        if (raw.isEmpty()) return m
        for (pair in raw.split("&")) {
            val i = pair.indexOf('=')
            try {
                if (i > 0) {
                    m[URLDecoder.decode(pair.substring(0, i), "UTF-8")] =
                        URLDecoder.decode(pair.substring(i + 1), "UTF-8")
                }
            } catch (e: Exception) {
                // skip malformed pair
            }
        }
        return m
    }

    private fun send(out: OutputStream, code: Int, type: String, body: ByteArray) {
        val status = when (code) {
            200 -> "OK"
            400 -> "Bad Request"
            403 -> "Forbidden"
            404 -> "Not Found"
            405 -> "Method Not Allowed"
            411 -> "Length Required"
            429 -> "Too Many Requests"
            507 -> "Insufficient Storage"
            else -> "Error"
        }
        val head = "HTTP/1.1 $code $status\r\n" +
            "Content-Type: $type\r\n" +
            "Content-Length: ${body.size}\r\n" +
            "Cache-Control: no-store\r\n" +
            "Connection: close\r\n\r\n"
        out.write(head.toByteArray(Charsets.ISO_8859_1))
        out.write(body)
        out.flush()
    }

    private fun json(out: OutputStream, code: Int, obj: JSONObject) =
        send(out, code, "application/json; charset=utf-8", obj.toString().toByteArray(Charsets.UTF_8))

    private fun sendError(out: OutputStream, code: Int, msg: String) =
        json(out, code, JSONObject().put("error", msg))
}
