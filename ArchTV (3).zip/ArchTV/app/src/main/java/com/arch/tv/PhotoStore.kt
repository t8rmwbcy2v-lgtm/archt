package com.arch.tv

import android.content.Context
import java.io.File

/** The photos you've added yourself, kept in Arch TV's own folder. */
object PhotoStore {
    val EXT = setOf("jpg", "jpeg", "png", "webp", "gif", "bmp")

    fun dir(ctx: Context): File {
        val base = ctx.getExternalFilesDir(null) ?: ctx.filesDir
        return File(base, "Photos").apply { mkdirs() }
    }

    fun list(ctx: Context): List<File> =
        dir(ctx).listFiles()
            ?.filter { it.isFile && it.extension.lowercase() in EXT && !it.name.endsWith(".part") }
            ?.sortedBy { it.name.lowercase() }
            ?: emptyList()
}
