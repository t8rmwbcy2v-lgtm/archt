package com.arch.tv

import java.io.File
import java.net.HttpURLConnection
import java.net.URL

object Net {
    private const val UA = "ArchTV/1.1"

    fun get(url: String, timeoutMs: Int = 10_000): String? {
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = timeoutMs
            c.readTimeout = timeoutMs
            c.setRequestProperty("User-Agent", UA)
            if (c.responseCode !in 200..299) {
                c.disconnect()
                return null
            }
            val text = c.inputStream.bufferedReader().use { it.readText() }
            c.disconnect()
            text
        } catch (e: Exception) {
            null
        }
    }

    fun download(url: String, dest: File): Boolean {
        val tmp = File(dest.path + ".tmp")
        return try {
            val c = URL(url).openConnection() as HttpURLConnection
            c.connectTimeout = 10_000
            c.readTimeout = 20_000
            c.setRequestProperty("User-Agent", UA)
            if (c.responseCode !in 200..299) {
                c.disconnect()
                return false
            }
            c.inputStream.use { input -> tmp.outputStream().use { input.copyTo(it) } }
            c.disconnect()
            tmp.renameTo(dest)
        } catch (e: Exception) {
            tmp.delete()
            false
        }
    }
}
